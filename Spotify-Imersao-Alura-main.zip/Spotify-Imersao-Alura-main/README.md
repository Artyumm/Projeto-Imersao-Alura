Este foi um projeto realizado em conjunto com a Alura em uma imersão de Front-end (ensinado por Fernanda Degolin, a Mayara Cardoso e Guilherme Lima). Foi abordado diversos pontos de HTML, CSS e JAVASCRIPT visando criar uma página inicial igual ao do Spotify.
Foi visto um pouco por cima sobre React (tecnologia de Framework).
